package edu.klh.matching;
import org.springframework.boot.*;import org.springframework.boot.autoconfigure.*;
@SpringBootApplication public class MatchingApplication{public static void main(String[] args){SpringApplication.run(MatchingApplication.class,args);}}
