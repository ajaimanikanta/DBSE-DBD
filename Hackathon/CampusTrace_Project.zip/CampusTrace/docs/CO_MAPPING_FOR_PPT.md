# CAMPUS TRACE — Presentation Guide (Problem Statement 17)

1. **Title** CampusTrace — Smart Campus Lost & Found Management System
2. **CO1, 15 marks** Problem, requirements and use-case diagram. Manual WhatsApp messages and noticeboard reports are fragmented; centralized searchable reports and owner claims.
3. **CO1, 15 marks** ERD: User 1:N Item; User 1:N Claim; Item 1:N Claim. Primary keys and foreign keys.
4. **CO2, 15 marks** JPA/Hibernate entities and MySQL persistent CRUD, tables `app_users`, `items`, `claims`; show MySQL screenshots.
5. **CO3, 15 marks** Spring Boot endpoints GET/POST/PUT/DELETE, Spring Security, validation and error responses. Show Postman/network screenshots.
6. **CO4, 15 marks** 2 Spring Boot services: core API port 8080, match-scoring service port 8081. Explain HTTP POST integration and local fallback, **demonstrate both processes running**.
7. **CO5, 20 marks** Explainable smart match engine: category 40%, location 25%, title/description words 25%, date up to 10%. Demo and explain false-positive safety.
8. **CO5, 20 marks** SQL relational integrity, indexes on `(type,status)` and category, bounded top-10 match list, duplicate claim prevention.
9. **CO6, 20 marks** Website screenshots: Explore, Report form, Matches, Claim, Admin Review.
10. **CO6, 20 marks** Live end-to-end demo and testing, challenges/limitations, industry uses. Final table CO1–CO6 ↔ implementation evidence.

**Architecture**: Browser (React 5173) --HTTP/JSON--> Main Spring Boot API (8080) --Spring Data JPA--> MySQL (3306). Main API --HTTP POST--> matching Spring Boot service (8081).

**Demo flow**: Student A reports LOST earbuds. Student B reports FOUND earbuds. Match engine suggests candidate. Student A requests claim with private proof. Admin approves after verifying. System changes FOUND item to RETURNED and records claim status.

**Important:** Do not claim Python, machine learning, deployed cloud, automated identity verification or production security; those are not part of the current MVP. Only include working screenshots for finished features.
