# CampusTrace — Smart Campus Lost & Found (Problem #17)

**Stack:** React + Vite frontend • Java 17 / Spring Boot REST backend • MySQL / Spring Data JPA • Spring Security HTTP Basic + BCrypt • Optional independently running Java Spring Boot matching microservice.

## Prerequisites
1. Install **JDK 17 or newer**, **Maven 3.9+**, **MySQL 8+**, **Node.js 18+**.
2. Start MySQL. Database is auto-created when the configured user has `CREATE DATABASE` permission (or run `CREATE DATABASE campustrace;`).
3. Set MySQL credentials via environment variables `DB_USER`, `DB_PASSWORD` (default root/root; change before demos), optionally `DB_URL`.

## Start (3 terminal windows)

**Terminal 1 — Spring Boot main backend**
```bash
cd backend
# Windows PowerShell, example: $env:DB_PASSWORD="YOUR_MYSQL_PASSWORD"
# Linux/macOS: export DB_PASSWORD="YOUR_MYSQL_PASSWORD"
mvn spring-boot:run
```
Main API: http://localhost:8080/api/health

**Terminal 2 — Independent matching backend** (for CO4)
```bash
cd matching-service
mvn spring-boot:run
```
Matching API: POST http://localhost:8081/match/score. If this service is down, main backend still matches locally; API results label `local-fallback` instead of `distributed`.

**Terminal 3 — React frontend**
```bash
cd frontend
npm install
npm run dev
```
Website: **http://localhost:5173**

For a production build of frontend: `npm run build`. Set `VITE_API_URL` if backend is elsewhere (default `http://localhost:8080/api`).

## Demo accounts

An admin account is seeded only if absent at startup:
- Email: `admin@campus.edu` (override `ADMIN_EMAIL`)
- Password: `ChangeMe123!` (override `ADMIN_PASSWORD` **before first startup**)

Create two student accounts using the Register dialog (e.g., demo1@campus.edu, demo2@campus.edu). Use distinct accounts to post and claim found items. Never use the demo credentials on a public deployment.

## 5-minute judge demo

1. Register first student -> **Report LOST** black earbuds, Library, category Electronics.
2. Log out; register second student -> **Report FOUND** black earbuds, Library, same date.
3. Click **Find matches** -> compare potential matches and scores, check `matchService` in browser DevTools Network to verify `distributed` service rather than local fallback.
4. First student logs in, chooses **Claim** on the FOUND report, provides ownership proof.
5. Admin logs in -> **Admin Review** -> Approve -> item transitions `OPEN` to `RETURNED` and duplicate pending claims are rejected.
6. Demonstrate MySQL persistence by refreshing page, and try invalid/duplicate claims to show validation.

## Key REST endpoints

| Method | Endpoint | Who | Purpose |
|---|---|---|---|
| POST | `/api/auth/register` | Public | Create student with BCrypt password |
| GET | `/api/auth/me` | Logged in | Authentication/role |
| GET | `/api/items` | Logged in | All reports with optional `type`, `query` |
| POST | `/api/items` | Logged in | Create lost or found report |
| PUT | `/api/items/{id}` | Owner/admin | Edit open report |
| DELETE | `/api/items/{id}` | Owner/admin | Delete report without claims |
| GET | `/api/items/{id}/matches` | Logged in | Smart ranked matches, microservice first |
| POST | `/api/items/{id}/claims` | Logged in | Request ownership verification of FOUND item |
| GET | `/api/claims/mine` | Logged in | Claim tracking |
| GET | `/api/admin/claims` | Admin | Review all claims |
| PUT | `/api/admin/claims/{id}` | Admin | Approve/reject claim |
| GET | `/api/admin/stats` | Admin | KPIs |
| POST | `/match/score` | Backend service | Separate matching microservice port 8081 |

## Security and limitations

- Demonstration-focused project. HTTP Basic over HTTP is **only appropriate on localhost**; use HTTPS, robust session/JWT auth, CSRF-aware browser design, rate limits and account controls before public deployment.
- Passwords are hashed with BCrypt in MySQL. Roles STUDENT and ADMIN; server checks item ownership.
- Ownership proof stays private in claims, rather than exposed in public item listings. Admin verifies proof manually; heuristic match scores are **not** proof of ownership.
- Uploading real images, email notifications, pagination and automated tests are not yet included.
- `ddl-auto=update` is for demos, not a migration strategy for production.
- The frontend shows sample cards in **Preview Mode** if the backend cannot be reached; it is read-only, **not** a substitute for real database/API proof. For evaluation, run all services and see **API Connected**.

## Database design / relations

`app_users(id, name, email UNIQUE, password BCrypt, role)` 1--many `items(id, title, description, type, category, location, event_date, status, reporter_id FK)`.

`claims(id, item_id FK, claimant_id FK, proof, status)` joins users and found items in a many-to-many relationship via claims.

## Faculty CO mapping

- **CO1:** Problem/requirements, ERD, entities + PK/FK.
- **CO2:** MySQL table relationships, JPA CRUD, unique index, persistence.
- **CO3:** Java Spring Boot REST endpoints, validation, error responses, role authorization.
- **CO4:** Two independently running Spring Boot backend processes (8080 and 8081), HTTP service-to-service matching; demonstrate via API `matchService: distributed`.
- **CO5:** Heuristic match scoring: same category 40, location 25, shared words up to 25, date proximity up to 10, threshold 20; sort descending. Explainable score, not claimed AI.
- **CO6:** Student report -> matching -> claim -> admin verify -> status update, responsive frontend, negative cases and persistence demo.
