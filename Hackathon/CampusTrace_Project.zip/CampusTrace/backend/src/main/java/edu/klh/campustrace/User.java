package edu.klh.campustrace;
import jakarta.persistence.*;
@Entity @Table(name="app_users") public class User {
 @Id @GeneratedValue(strategy=GenerationType.IDENTITY) public Long id;
 @Column(nullable=false) public String name;
 @Column(nullable=false,unique=true) public String email;
 @Column(nullable=false) public String password;
 @Column(nullable=false) public String role="STUDENT";
}
