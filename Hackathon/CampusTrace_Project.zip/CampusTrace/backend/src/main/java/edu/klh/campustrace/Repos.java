package edu.klh.campustrace;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.*;
interface UserRepo extends JpaRepository<User,Long>{Optional<User> findByEmailIgnoreCase(String email);}
interface ItemRepo extends JpaRepository<Item,Long>{List<Item> findByTypeAndStatus(String type,String status);}
interface ClaimRepo extends JpaRepository<Claim,Long>{List<Claim> findByClaimantId(Long id);List<Claim> findByItemId(Long id);}
