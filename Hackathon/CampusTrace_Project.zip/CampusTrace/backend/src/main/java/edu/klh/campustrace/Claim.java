package edu.klh.campustrace;
import jakarta.persistence.*;
import java.time.*;
@Entity @Table(name="claims") public class Claim {
 @Id @GeneratedValue(strategy=GenerationType.IDENTITY) public Long id;
 @ManyToOne(optional=false) public Item item;
 @ManyToOne(optional=false) public User claimant;
 @Column(length=1200,nullable=false) public String proof;
 @Column(nullable=false) public String status="PENDING";
 public LocalDateTime createdAt=LocalDateTime.now();
}
