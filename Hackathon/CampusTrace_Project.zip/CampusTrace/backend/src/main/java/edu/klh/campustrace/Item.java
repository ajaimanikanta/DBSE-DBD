package edu.klh.campustrace;
import jakarta.persistence.*;
import java.time.*;
@Entity @Table(name="items",indexes={@Index(name="idx_type_status",columnList="type,status"),@Index(name="idx_category",columnList="category")}) public class Item {
 @Id @GeneratedValue(strategy=GenerationType.IDENTITY) public Long id;
 @Column(nullable=false) public String title;
 @Column(length=1500,nullable=false) public String description;
 @Column(nullable=false) public String type; // LOST or FOUND
 @Column(nullable=false) public String category;
 @Column(nullable=false) public String location;
 @Column(nullable=false) public LocalDate eventDate;
 @Column(nullable=false) public String status="OPEN";
 @ManyToOne(optional=false) public User reporter;
 public LocalDateTime createdAt=LocalDateTime.now();
}
