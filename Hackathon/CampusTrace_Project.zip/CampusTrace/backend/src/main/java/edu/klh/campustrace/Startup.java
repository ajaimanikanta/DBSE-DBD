package edu.klh.campustrace;
import org.springframework.boot.*;
import org.springframework.context.annotation.*;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.crypto.password.PasswordEncoder;
@Configuration public class Startup {
 @Bean CommandLineRunner adminSeed(UserRepo repo,PasswordEncoder encoder,@Value("${app.admin.email}")String email,@Value("${app.admin.password}")String password){return args->{if(repo.findByEmailIgnoreCase(email).isEmpty()){User u=new User();u.name="Campus Administrator";u.email=email;u.role="ADMIN";u.password=encoder.encode(password);repo.save(u);System.out.println("Demo admin account created: "+email+" (change password before public deployment)");}};}
}
