package edu.klh.campustrace;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
@SpringBootApplication public class CampusTraceApplication { public static void main(String[] args){SpringApplication.run(CampusTraceApplication.class,args);} }
